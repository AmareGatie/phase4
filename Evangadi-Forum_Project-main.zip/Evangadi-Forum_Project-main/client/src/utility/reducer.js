import { Type } from "./action.type";

export const initialState = {
  
};

export const reducer = (state, action) => {
  // switch statement with the action type cases goes here
};
