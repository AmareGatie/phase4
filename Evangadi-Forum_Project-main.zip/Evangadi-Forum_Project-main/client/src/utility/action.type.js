export const Type = {
  // we will add types here
  
};
