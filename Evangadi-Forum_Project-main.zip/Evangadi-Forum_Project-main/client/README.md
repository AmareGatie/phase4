# EVANGADI FORUM PROJECT - EVANGADI BOOTCAMP

## project collaboration links
- click up https://app.clickup.com/9012320352/v/l/8cju630-452
- Github Repo https://github.com/Fantahun/EvangadiForumProject

test for branching
GIT PULL, PUSH AND PULL REQUEST TEST WITH THE BELOVED TEAM MATES 🤝
  Mohammed: Hi everyone
  Helen shiferaw:  hi everyone
  Dawit: test for git status
