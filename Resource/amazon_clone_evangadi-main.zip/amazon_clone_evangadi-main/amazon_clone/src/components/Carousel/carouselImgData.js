import img1 from '../../assets/images/carousal/game_store.jpg';
import img2 from '../../assets/images/carousal/beauty_products.jpg';
import img3 from '../../assets/images/carousal/kitchen_fav.jpg';
import img4 from '../../assets/images/carousal/new_arrival_toys.jpg';
import img5 from '../../assets/images/carousal/shop_books.jpg';

export const img = [img1, img2, img3, img4, img5];


