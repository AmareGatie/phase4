# Amazon replica react learining path ...

## deployed frontend: https://amazon-clone-evangadi.vercel.app/orders
## deployed backend : https://amazon-backend-kjkt.onrender.com

